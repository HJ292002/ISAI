import java.util.Scanner;

public class Assign1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String string = sc.nextLine();
        StringBuilder resultAnd = new StringBuilder();
        StringBuilder resultOr = new StringBuilder();
        StringBuilder resultXor = new StringBuilder();

        for (int i = 0; i < string.length(); i++) {
            char c = string.charAt(i);
            int andVal = c & 127;
            int orVal = c | 127;
            int xorVal = c ^ 127;

            resultAnd.append((char) andVal);
            resultOr.append((char) orVal);
            resultXor.append((char) xorVal);
        }

        System.out.println("Original string: " + string);
        System.out.println("AND result: " + resultAnd);
        System.out.println("OR result: " + resultOr);
        System.out.println("XOR result: " + resultXor);
    }
}
