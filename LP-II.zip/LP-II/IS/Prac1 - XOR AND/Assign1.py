string = input("Enter String : ")
result_and = ""
result_xor = ""
result_or = ""

for char in string:
    and_val = ord(char) & 127
    xor_val = ord(char) ^ 127
    or_val = ord(char) | 127
    
    
    result_and += chr(and_val)
    result_xor += chr(xor_val)
    result_or += chr(or_val)
    
print("Original string : ", string)
print("AND result : ", result_and)
print("OR result : " , result_or)
print("XOR result : ", result_xor)