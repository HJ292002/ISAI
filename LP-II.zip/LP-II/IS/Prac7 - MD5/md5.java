import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class md5 {
    public static void main(String[] args) {
        String input = "Hello, World!";

        try {
            // Create an instance of the MD5 algorithm
            MessageDigest md = MessageDigest.getInstance("MD5");

            // Compute the MD5 hash value
            byte[] hashBytes = md.digest(input.getBytes());

            // Convert the hash bytes to a hexadecimal string representation
            StringBuilder hexString = new StringBuilder();
            for (byte hashByte : hashBytes) {
                String hex = Integer.toHexString(0xff & hashByte);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }

            // Print the MD5 hash value
            System.out.println("MD5 Hash Value: " + hexString.toString());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }
}
