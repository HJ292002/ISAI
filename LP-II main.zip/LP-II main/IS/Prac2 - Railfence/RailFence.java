public class RailFence {
    public static String encrypt(String plaintext, int rails) {
        char[][] fence = new char[rails][plaintext.length()];
        boolean down = false;
        int row = 0, col = 0;

        for (int i = 0; i < plaintext.length(); i++) {
            if (row == 0 || row == rails - 1)
                down = !down;

            fence[row][col++] = plaintext.charAt(i);

            if (down)
                row++;
            else
                row--;
        }

        // Construct the encrypted text
        char[] encryptedText = new char[plaintext.length()];
        int index = 0;
        for (int i = 0; i < rails; i++) {
            for (int j = 0; j < plaintext.length(); j++) {
                if (fence[i][j] != 0)
                    encryptedText[index++] = fence[i][j];
            }
        }

        return new String(encryptedText);
    }

    public static String decrypt(String encryptedText, int rails) {
        char[][] fence = new char[rails][encryptedText.length()];
        boolean down = false;
        int row = 0, col = 0;

        // Build the rail fence pattern
        for (int i = 0; i < encryptedText.length(); i++) {
            if (row == 0 || row == rails - 1)
                down = !down;

            fence[row][col++] = '*';

            if (down)
                row++;
            else
                row--;
        }

        // Fill the rail fence with encrypted text characters
        int index = 0;
        for (int i = 0; i < rails; i++) {
            for (int j = 0; j < encryptedText.length(); j++) {
                if (fence[i][j] == '*' && index < encryptedText.length())
                    fence[i][j] = encryptedText.charAt(index++);
            }
        }

        // Read the rail fence to construct the decrypted text
        char[] decryptedText = new char[encryptedText.length()];
        down = false;
        row = 0;
        col = 0;

        for (int i = 0; i < encryptedText.length(); i++) {
            if (row == 0 || row == rails - 1)
                down = !down;

            decryptedText[i] = fence[row][col++];

            if (down)
                row++;
            else
                row--;
        }

        return new String(decryptedText);
    }

    public static void main(String[] args) {
        String plaintext = "Hello, World!";
        int rails = 3;

        String encryptedText = encrypt(plaintext, rails);
        System.out.println("Encrypted Text: " + encryptedText);

        String decryptedText = decrypt(encryptedText, rails);
        System.out.println("Decrypted Text: " + decryptedText);
    }
}
