from Crypto.Cipher import DES
from Crypto.Util.Padding import pad, unpad
import base64

def encrypt(plaintext, key):
    cipher = DES.new(key, DES.MODE_ECB)
    padded_plaintext = pad(plaintext.encode(), DES.block_size)
    ciphertext = cipher.encrypt(padded_plaintext)
    return base64.b64encode(ciphertext).decode()

def decrypt(ciphertext, key):
    cipher = DES.new(key, DES.MODE_ECB)
    ciphertext = base64.b64decode(ciphertext)
    padded_plaintext = cipher.decrypt(ciphertext)
    plaintext = unpad(padded_plaintext, DES.block_size).decode()
    return plaintext

key = b'01234567'  # 8-byte key
plaintext = 'Hello, DES!'

encrypted_text = encrypt(plaintext, key)
print("Encrypted: ", encrypted_text)

decrypted_text = decrypt(encrypted_text, key)
print("Decrypted: ", decrypted_text)
