/**
 * 
 */
/**
 * @author Maddy
 *
 */
module IS6 {
}